#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  Physics-Informed Neural Network (PINN) for Raman Spectroscopy              ║
║  DIG4BIO Raman Transfer Learning Challenge                                   ║
║                                                                              ║
║  Physics Laws Encoded in the Loss Function:                                  ║
║  ─────────────────────────────────────────                                   ║
║  1. Beer–Lambert Law         : I = ε·l·c  →  spectrum ∝ concentration       ║
║  2. Superposition Principle  : mixture = Σ(cᵢ·εᵢ) (pure component spectra)  ║
║  3. Non-negativity           : concentrations ≥ 0, spectra ≥ 0 after BG     ║
║  4. Spectral Smoothness      : no jagged spectra (Lorentzian peak shapes)    ║
║  5. Fingerprint Invariance   : augmented spectrum → same concentration        ║
║  6. Raman Selection Rules    : pure component spectra ≥ 0 and smooth         ║
║  7. Raman Intensity Law      : intensity scales linearly with concentration   ║
║  8. Harmonic Phonon Approx.  : TV/2nd-deriv regularisation on pure spectra   ║
║  9. Mass Balance             : concentrations within physically valid bounds  ║
║  10. Conservation of signal  : total reconstruction error bounded            ║
║                                                                              ║
║  Architecture:                                                               ║
║  ─────────────                                                               ║
║  Spectrum → [MSC → SNIP-baseline → SavGol → StandardScale]                  ║
║          → 1D-ResNet encoder (3 blocks, 128 channels)                        ║
║          → Multi-head spectral attention (fingerprint emphasis)              ║
║          → Softplus-constrained concentration head (non-negativity)          ║
║          → Beer–Lambert decoder (learnable pure component spectra)           ║
║                                                                              ║
║  Training:                                                                   ║
║  ─────────                                                                   ║
║  • 5-fold cross-validation                                                   ║
║  • Spectrum augmentation: scale, baseline drift, wavenumber shift, noise     ║
║  • Cosine annealing LR schedule with warm restarts                           ║
║  • Physics loss warm-up (gradually increase physics weight)                  ║
║  • Test-time augmentation (TTA) × 16 samples                                 ║
║  • Ensemble across all 5 folds                                               ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage (Kaggle):
    python pinn_raman.py

Requirements:
    pip install torch numpy pandas scipy pybaselines scikit-learn
"""

from __future__ import annotations

import os
import warnings
import argparse
from dataclasses import dataclass, field
from typing import Optional, Tuple, List, Dict

import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from scipy.stats import skew, kurtosis
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset, Dataset

warnings.filterwarnings("ignore")

# ──────────────────────────────────────────────────────────────────────────────
# 0. Configuration
# ──────────────────────────────────────────────────────────────────────────────

DATA_DIR  = "/kaggle/input/dig-4-bio-raman-transfer-learning-challenge"
OUT_DIR   = "./pinn_outputs"
SEED      = 42

# Wavenumber grid (matches the truncation in winning solutions)
WN_LOW    = 300.0
WN_HIGH   = 1942.0
WN_STEP   = 1.0          # 1 cm⁻¹ steps  → 1643 bins

# Neural network
HIDDEN_DIM    = 256
N_CONV_BLOCKS = 3
DROPOUT       = 0.20
N_TARGETS     = 3

# Training
N_FOLDS       = 5
EPOCHS        = 600
BATCH_SIZE    = 32
LR            = 3e-3
WEIGHT_DECAY  = 1e-4
TTA_N         = 16          # test-time augmentation samples

# Physics loss weights (ramped up after `PHYS_WARMUP` epochs)
PHYS_WARMUP   = 30
LW_MSE        = 1.00        # standard regression MSE
LW_BEER       = 0.15        # Beer-Lambert reconstruction
LW_NONNEG_C   = 0.80        # concentration non-negativity
LW_NONNEG_S   = 0.05        # reconstructed-spectrum non-negativity
LW_SMOOTH     = 0.05        # spectral smoothness (2nd derivative)
LW_INV        = 0.10        # invariance augmentation
LW_MASS       = 0.20        # mass-balance soft constraint
LW_PURE_SMOOTH= 0.02        # pure-component spectra smoothness

# Augmentation parameters
AUG_SCALE     = (0.85, 1.15)
AUG_BASE_AMP  = 0.04
AUG_BASE_DEG  = 2
AUG_MAX_SHIFT = 2.0          # cm⁻¹
AUG_NOISE_STD = 0.005

# Physically motivated concentration bounds (g/L)
CONC_MAX = [15.0, 3.0, 4.0]   # Glucose, Sodium Acetate, Magnesium Acetate


# ──────────────────────────────────────────────────────────────────────────────
# 1. Utility helpers
# ──────────────────────────────────────────────────────────────────────────────

def set_seed(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def make_grid(lo: float, hi: float, step: float) -> np.ndarray:
    n = int(round((hi - lo) / step)) + 1
    return (lo + step * np.arange(n, dtype=np.float64)).astype(np.float32)


# ──────────────────────────────────────────────────────────────────────────────
# 2. Data loading (plate format: 2 replicates × 2048 columns)
# ──────────────────────────────────────────────────────────────────────────────

def _clean_brackets(series: pd.Series) -> pd.Series:
    return pd.to_numeric(
        series.astype(str).str.replace("[", "", regex=False).str.replace("]", "", regex=False),
        errors="coerce",
    )


def load_plate(filepath: str, is_train: bool) -> Tuple[np.ndarray, Optional[np.ndarray]]:
    """
    Load transfer_plate.csv (train) or 96_samples.csv (test).
    Returns X: (N_samples, 2048) averaged over 2 replicates, y: (N_samples, 3) or None.
    """
    if is_train:
        df = pd.read_csv(filepath)
        target_cols = ["Glucose (g/L)", "Sodium Acetate (g/L)", "Magnesium Acetate (g/L)"]
        y = df[target_cols].dropna().values.astype(np.float32)
        Xdf = df.iloc[:, :-4].copy()
    else:
        df = pd.read_csv(filepath, header=None)
        y = None
        Xdf = df.copy()

    Xdf.columns = ["sample_id"] + [str(i) for i in range(Xdf.shape[1] - 1)]
    Xdf["sample_id"] = Xdf["sample_id"].ffill()

    for col in Xdf.columns[1:]:
        Xdf[col] = _clean_brackets(Xdf[col])

    X = Xdf.drop(columns=["sample_id"]).values.astype(np.float32)
    X = X.reshape(-1, 2, 2048).mean(axis=1)          # average replicates
    return X, y


def plate_to_grid(X_2048: np.ndarray, grid_wns: np.ndarray,
                  wn_start: float = 65.0, wn_end: float = 3350.0) -> np.ndarray:
    """Interpolate 2048-point plate spectrum onto shared wavenumber grid."""
    full_wns = np.linspace(wn_start, wn_end, 2048, dtype=np.float64)
    lo, hi = float(grid_wns.min()), float(grid_wns.max())
    sel = (full_wns >= lo) & (full_wns <= hi)
    wns_sel = full_wns[sel]
    X_sel = X_2048[:, sel].astype(np.float64)
    return np.array(
        [np.interp(grid_wns, xp=wns_sel, fp=row) for row in X_sel], dtype=np.float32
    )


# ──────────────────────────────────────────────────────────────────────────────
# 3. Preprocessing pipeline
# ──────────────────────────────────────────────────────────────────────────────

def apply_msc(X: np.ndarray, ref: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
    """
    Multiplicative Scatter Correction.
    Corrects for scattering differences between spectra.
    Returns corrected spectra and reference used.
    """
    X64 = X.astype(np.float64)
    if ref is None:
        ref = X64.mean(axis=0)
    out = np.empty_like(X64)
    for i in range(X64.shape[0]):
        slope, intercept = np.polyfit(ref, X64[i], 1)
        out[i] = (X64[i] - intercept) / (slope + 1e-12)
    return out.astype(np.float32), ref.astype(np.float32)


def apply_snip_baseline(X: np.ndarray,
                        max_half_window: int = 20,
                        smooth_half_window: int = 3) -> np.ndarray:
    """
    SNIP (Statistics-sensitive Non-linear Iterative Peak-clipping) baseline removal.
    Physics motivation: separates fluorescence background from Raman signal.
    """
    try:
        import pybaselines
        fitter = pybaselines.Baseline()
        X64 = X.astype(np.float64)
        out = np.empty_like(X64)
        for i in range(X64.shape[0]):
            base, _ = fitter.snip(X64[i], max_half_window=max_half_window,
                                  decreasing=True, smooth_half_window=smooth_half_window)
            out[i] = X64[i] - base
        return out.astype(np.float32)
    except ImportError:
        # Fallback: polynomial baseline
        print("[WARN] pybaselines not installed; using polynomial baseline fallback.")
        return apply_poly_baseline(X)


def apply_poly_baseline(X: np.ndarray, degree: int = 3) -> np.ndarray:
    """Polynomial baseline subtraction as SNIP fallback."""
    X64 = X.astype(np.float64)
    t = np.linspace(0, 1, X64.shape[1], dtype=np.float64)
    out = np.empty_like(X64)
    for i in range(X64.shape[0]):
        coef = np.polyfit(t, X64[i], degree)
        out[i] = X64[i] - np.polyval(coef, t)
    return out.astype(np.float32)


def apply_savgol(X: np.ndarray, window: int = 7, polyorder: int = 2, deriv: int = 0) -> np.ndarray:
    """
    Savitzky-Golay smoothing.
    Physics motivation: Raman peaks have smooth Lorentzian/Voigt shapes.
    """
    return savgol_filter(X.astype(np.float64),
                         window_length=window, polyorder=polyorder,
                         deriv=deriv, axis=1).astype(np.float32)


@dataclass
class Preprocessor:
    """Fit-transform preprocessing state (MSC ref + StandardScaler)."""
    msc_ref: Optional[np.ndarray] = None
    scaler: Optional[StandardScaler] = None

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        X, self.msc_ref = apply_msc(X, ref=None)
        X = apply_snip_baseline(X)
        X = apply_savgol(X, window=7, polyorder=2, deriv=0)
        self.scaler = StandardScaler()
        X = self.scaler.fit_transform(X).astype(np.float32)
        return X

    def transform(self, X: np.ndarray) -> np.ndarray:
        X, _ = apply_msc(X, ref=self.msc_ref)
        X = apply_snip_baseline(X)
        X = apply_savgol(X, window=7, polyorder=2, deriv=0)
        X = self.scaler.transform(X).astype(np.float32)
        return X


# ──────────────────────────────────────────────────────────────────────────────
# 4. Spectral augmentation (for invariance loss and data augmentation)
# ──────────────────────────────────────────────────────────────────────────────

def augment_spectra(X: np.ndarray, wns: np.ndarray, rng: np.random.RandomState,
                    scale_range: Tuple = (0.85, 1.15),
                    baseline_amp: float = 0.04,
                    baseline_degree: int = 2,
                    max_shift: float = 2.0,
                    noise_std: float = 0.005) -> np.ndarray:
    """
    Physics-motivated invariance augmentations:
    - Intensity scaling       → Beer-Lambert intensity variation
    - Baseline drift          → Fluorescence background simulation
    - Wavenumber shift        → Instrument calibration drift
    - Additive noise          → Shot/thermal noise

    Concentrations should be INVARIANT to these transforms.
    """
    X = X.astype(np.float32)
    wns = wns.astype(np.float32)
    N, D = X.shape
    out = X.copy()

    # 1) Intensity scaling  (Beer-Lambert: I = ε·l·c — path length variation)
    lo, hi = float(scale_range[0]), float(scale_range[1])
    scales = rng.uniform(lo, hi, size=(N, 1)).astype(np.float32)
    out *= scales

    # 2) Baseline drift  (fluorescence / dark current)
    if baseline_amp > 0:
        t = np.linspace(0, 1, D, dtype=np.float32)
        for i in range(N):
            coeffs = rng.normal(0, 1, baseline_degree + 1).astype(np.float32)
            base = sum(c * t**k for k, c in enumerate(coeffs)).astype(np.float32)
            base -= base.mean()
            denom = base.std() + 1e-8
            base /= denom
            amp = rng.uniform(-baseline_amp, baseline_amp) * float(np.max(np.abs(out[i])) + 1e-8)
            out[i] += amp * base

    # 3) Wavenumber shift  (instrument calibration drift)
    if max_shift > 0:
        shifts = rng.uniform(-max_shift, max_shift, size=(N,)).astype(np.float32)
        out_shifted = np.empty_like(out)
        for i in range(N):
            q = (wns - shifts[i]).astype(np.float64)
            out_shifted[i] = np.interp(q, wns.astype(np.float64), out[i].astype(np.float64)).astype(np.float32)
        out = out_shifted

    # 4) Additive noise  (photon shot noise)
    if noise_std > 0:
        out += rng.normal(0, noise_std, size=out.shape).astype(np.float32)

    return out


# ──────────────────────────────────────────────────────────────────────────────
# 5. Neural network architecture
# ──────────────────────────────────────────────────────────────────────────────

class ConvResBlock(nn.Module):
    """
    1D Residual block with GELU activation and LayerNorm.
    Captures local spectral patterns at multiple scales.
    """
    def __init__(self, channels: int, kernel_size: int, dilation: int = 1):
        super().__init__()
        pad = (kernel_size - 1) * dilation // 2
        self.block = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
            nn.GELU(),
            nn.Dropout(0.05),
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
        )
        self.norm = nn.GroupNorm(8, channels)
        self.act  = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.norm(x + self.block(x)))


class SpectralAttention(nn.Module):
    """
    Self-attention over wavenumber positions.
    Physics motivation: Raman fingerprint regions have correlated peaks;
    attention learns which regions to focus on per analyte.
    """
    def __init__(self, channels: int, n_heads: int = 4):
        super().__init__()
        self.attn = nn.MultiheadAttention(channels, n_heads, dropout=0.1, batch_first=True)
        self.norm = nn.LayerNorm(channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, C, L) → transpose for MHA → (B, L, C)
        xt = x.permute(0, 2, 1)
        attn_out, _ = self.attn(xt, xt, xt)
        xt = self.norm(xt + attn_out)
        return xt.permute(0, 2, 1)


class RamanPINN(nn.Module):
    """
    Physics-Informed Neural Network for Raman spectroscopy.

    Encoder: 1D-ResNet with dilation + spectral attention
    Head:    Softplus output (enforces cᵢ ≥ 0 by construction — non-negativity law)
    Decoder: Learnable pure-component spectra matrix E ∈ R^{3 × D}
             Reconstructs mixture: x̂ = cᵀ·E  (Beer–Lambert + Superposition)
    """

    def __init__(self, input_dim: int, hidden_dim: int = 256,
                 n_targets: int = 3, dropout: float = 0.2):
        super().__init__()
        self.input_dim = input_dim
        self.n_targets = n_targets

        # ── Stem
        self.stem = nn.Sequential(
            nn.Conv1d(1, hidden_dim // 4, kernel_size=15, padding=7),
            nn.GELU(),
            nn.Conv1d(hidden_dim // 4, hidden_dim // 2, kernel_size=9, padding=4),
            nn.GELU(),
            nn.Conv1d(hidden_dim // 2, hidden_dim, kernel_size=7, padding=3),
            nn.GELU(),
        )

        # ── Residual blocks with increasing dilation (multi-scale context)
        self.res_blocks = nn.ModuleList([
            ConvResBlock(hidden_dim, kernel_size=7, dilation=1),
            ConvResBlock(hidden_dim, kernel_size=5, dilation=2),
            ConvResBlock(hidden_dim, kernel_size=5, dilation=4),
            ConvResBlock(hidden_dim, kernel_size=3, dilation=8),
        ])

        # ── Spectral attention (fingerprint-region focus)
        self.attn = SpectralAttention(hidden_dim, n_heads=4)

        # ── Global pooling with learned weights (soft attention over positions)
        self.pool_weights = nn.Sequential(
            nn.Conv1d(hidden_dim, 1, kernel_size=1),
            nn.Softmax(dim=-1),
        )

        # ── Concentration prediction head
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, hidden_dim // 4),
            nn.GELU(),
            nn.Dropout(dropout / 2),
            nn.Linear(hidden_dim // 4, n_targets),
        )

        # ── Beer–Lambert decoder: pure-component spectra (physics prior)
        # E[i] = pure spectrum of analyte i
        # Physics constraint: E[i] ≥ 0, smooth → enforced in loss
        self.pure_spectra = nn.Parameter(
            torch.abs(torch.randn(n_targets, input_dim)) * 0.1
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, D) → features: (B, hidden_dim)"""
        # Add channel dimension
        h = x.unsqueeze(1)                         # (B, 1, D)
        h = self.stem(h)                           # (B, C, D)
        for blk in self.res_blocks:
            h = blk(h)                             # (B, C, D)
        h = self.attn(h)                           # (B, C, D)
        # Soft attention pooling
        w = self.pool_weights(h)                   # (B, 1, D)
        feats = (h * w).sum(dim=-1)                # (B, C)
        return feats

    def predict_concentrations(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, D) → concentrations: (B, 3), non-negative via Softplus."""
        feats = self.encode(x)
        raw   = self.head(feats)
        # Softplus ensures cᵢ > 0 (Beer-Lambert non-negativity)
        return F.softplus(raw)

    def reconstruct_spectrum(self, c: torch.Tensor) -> torch.Tensor:
        """
        Beer–Lambert + Superposition law:
        x̂ = Σᵢ cᵢ · Eᵢ  where Eᵢ = pure component spectrum of analyte i

        c: (B, 3),  pure_spectra: (3, D) → x̂: (B, D)
        """
        # Ensure pure spectra are non-negative (Raman signal ≥ 0)
        E = F.softplus(self.pure_spectra)          # (3, D)
        return c @ E                               # (B, D)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Returns (concentrations, reconstructed_spectrum)."""
        c   = self.predict_concentrations(x)
        x_r = self.reconstruct_spectrum(c)
        return c, x_r


# ──────────────────────────────────────────────────────────────────────────────
# 6. Physics-informed loss function
# ──────────────────────────────────────────────────────────────────────────────

class PhysicsInformedLoss(nn.Module):
    """
    Multi-component loss combining standard regression with physical constraints.

    Physics laws encoded:
    ─────────────────────
    1. Beer-Lambert (Reconstruction)   : ||x - c·E||²
    2. Non-negativity concentrations   : Σ ReLU(-c)²
    3. Non-negativity reconstructed    : Σ ReLU(-x_recon)²
    4. Spectral smoothness             : ||∇²x_recon||²   (harmonic approx.)
    5. Fingerprint invariance          : ||c - c_aug||²   (RamanSR: peak pos. fixed)
    6. Pure-component smoothness       : ||∇²E||²         (Lorentzian peaks)
    7. Mass-balance soft constraint    : penalise c > CONC_MAX
    8. Raman Intensity Law             : reconstruction ≥ 0 (light non-negative)
    """

    def __init__(self, conc_max: List[float], phys_warmup: int = 30):
        super().__init__()
        self.conc_max    = torch.tensor(conc_max, dtype=torch.float32)
        self.phys_warmup = phys_warmup

    def _tv2(self, x: torch.Tensor) -> torch.Tensor:
        """2nd-order total variation (penalises jagged spectra)."""
        d2 = x[:, 2:] - 2 * x[:, 1:-1] + x[:, :-2]
        return d2.pow(2).mean()

    def _tv2_1d(self, x: torch.Tensor) -> torch.Tensor:
        """2nd-order TV for 1D vector (pure component spectra)."""
        d2 = x[2:] - 2 * x[1:-1] + x[:-2]
        return d2.pow(2).mean()

    def forward(
        self,
        pred_c: torch.Tensor,      # (B, 3) predicted concentrations
        true_c: torch.Tensor,      # (B, 3) ground-truth concentrations
        x_input: torch.Tensor,     # (B, D) input spectrum (normalised)
        x_recon: torch.Tensor,     # (B, D) reconstructed spectrum
        pure_spectra: torch.Tensor,# (3, D) learnable pure component spectra
        epoch: int,
        pred_c_aug: Optional[torch.Tensor] = None,  # (B, 3) pred under augmented x
    ) -> Dict[str, torch.Tensor]:

        device = pred_c.device
        conc_max = self.conc_max.to(device)

        # ── Physics ramp-up factor (0 → 1 over first phys_warmup epochs)
        phys_w = min(1.0, epoch / max(self.phys_warmup, 1))
        pw = torch.tensor(phys_w, device=device)

        losses = {}

        # ① Standard regression MSE (primary task)
        losses["mse"] = F.mse_loss(pred_c, true_c)

        # ② Beer–Lambert Reconstruction Loss
        # ||normalised_input - reconstructed||²
        # Enforces: spectrum IS a linear superposition of component spectra × conc.
        losses["beer_lambert"] = F.mse_loss(x_recon, x_input) * pw

        # ③ Non-negativity of concentrations
        # Physical law: you cannot have negative concentrations (Beer-Lambert)
        losses["nonneg_conc"] = F.relu(-pred_c).pow(2).mean() * pw

        # ④ Non-negativity of reconstructed spectrum
        # Physical law: Raman signal (photon counts) cannot be negative
        losses["nonneg_spec"] = F.relu(-x_recon).pow(2).mean() * pw

        # ⑤ Spectral smoothness of reconstruction
        # Raman peaks are smooth Lorentzians / Voigt profiles (harmonic oscillator)
        losses["smooth_recon"] = self._tv2(x_recon) * pw

        # ⑥ Raman Selection Rules: pure component spectra must be smooth and non-negative
        E = F.softplus(pure_spectra)
        losses["pure_smooth"] = sum(self._tv2_1d(E[i]) for i in range(E.shape[0])) / E.shape[0] * pw

        # ⑦ Mass-balance constraint: concentrations within physically valid bounds
        # c_i ∈ [0, CONC_MAX_i]  — composition conservation
        losses["mass_balance"] = F.relu(pred_c - conc_max.unsqueeze(0)).pow(2).mean() * pw

        # ⑧ Fingerprint Invariance Loss
        # Raman fingerprint = peak POSITIONS fixed; only heights change.
        # Augmentation changes intensity/baseline/shift → predictions should be stable.
        # This enforces robustness to Raman instrument-to-instrument variation.
        if pred_c_aug is not None:
            losses["invariance"] = F.mse_loss(pred_c_aug, pred_c.detach()) * pw
        else:
            losses["invariance"] = torch.tensor(0.0, device=device)

        # ── Weighted total loss
        total = (
            LW_MSE         * losses["mse"]
          + LW_BEER        * losses["beer_lambert"]
          + LW_NONNEG_C    * losses["nonneg_conc"]
          + LW_NONNEG_S    * losses["nonneg_spec"]
          + LW_SMOOTH      * losses["smooth_recon"]
          + LW_PURE_SMOOTH * losses["pure_smooth"]
          + LW_MASS        * losses["mass_balance"]
          + LW_INV         * losses["invariance"]
        )
        losses["total"] = total
        return losses


# ──────────────────────────────────────────────────────────────────────────────
# 7. Training utilities
# ──────────────────────────────────────────────────────────────────────────────

class RamanDataset(Dataset):
    def __init__(self, X: np.ndarray, y: Optional[np.ndarray],
                 wns: np.ndarray, augment: bool = False):
        self.X       = torch.tensor(X, dtype=torch.float32)
        self.y       = torch.tensor(y, dtype=torch.float32) if y is not None else None
        self.wns     = wns.astype(np.float32)
        self.augment = augment
        self.rng     = np.random.RandomState(SEED)

    def __len__(self): return len(self.X)

    def __getitem__(self, idx):
        x = self.X[idx].numpy().copy()
        if self.augment:
            x_aug = augment_spectra(
                x[None], self.wns, self.rng,
                scale_range=AUG_SCALE, baseline_amp=AUG_BASE_AMP,
                baseline_degree=AUG_BASE_DEG, max_shift=AUG_MAX_SHIFT,
                noise_std=AUG_NOISE_STD,
            )[0]
        else:
            x_aug = x.copy()

        x_t     = torch.tensor(x,     dtype=torch.float32)
        x_aug_t = torch.tensor(x_aug, dtype=torch.float32)

        if self.y is not None:
            return x_t, x_aug_t, self.y[idx]
        else:
            return x_t, x_aug_t


def train_epoch(model: RamanPINN, loader: DataLoader,
                optimizer: torch.optim.Optimizer,
                criterion: PhysicsInformedLoss,
                epoch: int, device: torch.device) -> Dict[str, float]:
    model.train()
    totals: Dict[str, float] = {}

    for batch in loader:
        x, x_aug, y = batch
        x, x_aug, y = x.to(device), x_aug.to(device), y.to(device)

        # Forward pass on original spectrum
        pred_c, x_recon = model(x)

        # Forward pass on augmented spectrum (for invariance loss)
        with torch.no_grad():
            pass
        pred_c_aug, _ = model(x_aug)

        losses = criterion(
            pred_c, y, x, x_recon,
            model.pure_spectra,
            epoch,
            pred_c_aug=pred_c_aug,
        )

        optimizer.zero_grad()
        losses["total"].backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
        optimizer.step()

        for k, v in losses.items():
            totals[k] = totals.get(k, 0.0) + v.item()

    n = max(len(loader), 1)
    return {k: v / n for k, v in totals.items()}


@torch.no_grad()
def evaluate(model: RamanPINN, X: torch.Tensor, y: np.ndarray,
             device: torch.device) -> Tuple[np.ndarray, float]:
    model.eval()
    X = X.to(device)
    preds, _ = model(X)
    preds = preds.cpu().numpy()
    preds = np.maximum(preds, 0.0)            # post-process: clip negatives
    r2 = r2_score(y, preds)
    return preds, r2


@torch.no_grad()
def predict_tta(model: RamanPINN, X: np.ndarray, wns: np.ndarray,
                device: torch.device, n_tta: int = 16) -> np.ndarray:
    """Test-time augmentation: average n_tta predictions."""
    model.eval()
    rng = np.random.RandomState(0)
    preds_list = []

    # Original prediction
    Xt = torch.tensor(X, dtype=torch.float32).to(device)
    c, _ = model(Xt)
    preds_list.append(c.cpu().numpy())

    # Augmented predictions
    for _ in range(n_tta - 1):
        X_aug = augment_spectra(
            X, wns, rng,
            scale_range=AUG_SCALE, baseline_amp=AUG_BASE_AMP * 0.5,
            baseline_degree=AUG_BASE_DEG, max_shift=AUG_MAX_SHIFT * 0.5,
            noise_std=AUG_NOISE_STD * 0.5,
        )
        Xt = torch.tensor(X_aug, dtype=torch.float32).to(device)
        c, _ = model(Xt)
        preds_list.append(c.cpu().numpy())

    return np.mean(preds_list, axis=0)


# ──────────────────────────────────────────────────────────────────────────────
# 8. Post-processing
# ──────────────────────────────────────────────────────────────────────────────

def post_process(preds: np.ndarray, y_train: np.ndarray,
                 percentile_lo: float = 1.0, percentile_hi: float = 99.0) -> np.ndarray:
    """
    Physics-motivated post-processing:
    1. Non-negativity: clip to ≥ 0  (concentrations ≥ 0 always)
    2. Percentile bounds: clip to training distribution range (± margin)
    """
    target_names = ["Glucose (g/L)", "Sodium Acetate (g/L)", "Magnesium Acetate (g/L)"]
    out = np.maximum(preds, 0.0)

    for i, name in enumerate(target_names):
        lo = max(0.0, np.percentile(y_train[:, i], percentile_lo))
        hi = np.percentile(y_train[:, i], percentile_hi)
        margin = 0.12 * (hi - lo)
        lo = max(0.0, lo - margin)
        hi = hi + margin
        out[:, i] = np.clip(out[:, i], lo, hi)
        print(f"  {name}: clipped to [{lo:.3f}, {hi:.3f}]")

    return out


# ──────────────────────────────────────────────────────────────────────────────
# 9. Cross-validated training + ensemble
# ──────────────────────────────────────────────────────────────────────────────

def train_cv(X_train: np.ndarray, y_train: np.ndarray,
             X_test: np.ndarray, wns: np.ndarray,
             device: torch.device) -> Tuple[np.ndarray, np.ndarray, List[float]]:
    """
    5-fold cross-validation training.
    Returns:
        oof_preds : (N_train, 3) out-of-fold predictions
        test_preds: (N_test,  3) averaged test predictions across folds
        fold_r2s  : list of per-fold overall R² scores
    """
    kf          = KFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    oof_preds   = np.zeros_like(y_train, dtype=np.float32)
    test_preds  = np.zeros((X_test.shape[0], N_TARGETS), dtype=np.float32)
    fold_r2s    = []

    print(f"\n{'='*70}")
    print(f"  PINN Cross-Validation Training  ({N_FOLDS}-fold, {EPOCHS} epochs each)")
    print(f"{'='*70}")

    for fold, (tr_idx, val_idx) in enumerate(kf.split(X_train)):
        print(f"\n── Fold {fold+1}/{N_FOLDS} ──────────────────────────────────────────────")

        X_tr, X_val = X_train[tr_idx], X_train[val_idx]
        y_tr, y_val = y_train[tr_idx], y_train[val_idx]

        # Fit preprocessing on training fold only (no leakage)
        prep = Preprocessor()
        X_tr_p  = prep.fit_transform(X_tr)
        X_val_p = prep.transform(X_val)
        X_tst_p = prep.transform(X_test)

        # Build model
        model = RamanPINN(
            input_dim  = X_tr_p.shape[1],
            hidden_dim = HIDDEN_DIM,
            n_targets  = N_TARGETS,
            dropout    = DROPOUT,
        ).to(device)

        optimizer = torch.optim.AdamW(
            model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer, T_0=100, T_mult=2, eta_min=1e-5
        )
        criterion = PhysicsInformedLoss(
            conc_max=CONC_MAX, phys_warmup=PHYS_WARMUP
        )

        # Datasets & loaders
        train_ds = RamanDataset(X_tr_p, y_tr, wns, augment=True)
        train_dl = DataLoader(train_ds, batch_size=BATCH_SIZE,
                              shuffle=True, num_workers=0)

        best_val_r2   = -np.inf
        best_state    = None
        patience      = 0
        MAX_PATIENCE  = 120  # early stopping patience

        for epoch in range(1, EPOCHS + 1):
            tr_losses = train_epoch(model, train_dl, optimizer, criterion, epoch, device)
            scheduler.step(epoch)

            if epoch % 20 == 0 or epoch == EPOCHS:
                X_val_t = torch.tensor(X_val_p, dtype=torch.float32)
                val_preds, val_r2 = evaluate(model, X_val_t, y_val, device)

                if val_r2 > best_val_r2:
                    best_val_r2 = val_r2
                    best_state  = {k: v.cpu().clone() for k, v in model.state_dict().items()}
                    patience    = 0
                else:
                    patience += 1

                if epoch % 100 == 0:
                    target_r2s = [r2_score(y_val[:, i], val_preds[:, i]) for i in range(N_TARGETS)]
                    target_names = ["Glu", "NaAc", "MgAc"]
                    r2_str = "  ".join(f"{n}={v:.3f}" for n, v in zip(target_names, target_r2s))
                    print(f"  ep {epoch:4d} | loss {tr_losses['total']:.4f} | "
                          f"beer {tr_losses['beer_lambert']:.4f} | "
                          f"val R² {r2_str}  [best {best_val_r2:.4f}]")

                if patience >= MAX_PATIENCE // 20:  # patience in 20-ep units
                    print(f"  → Early stopping at epoch {epoch} (best R²={best_val_r2:.4f})")
                    break

        # Restore best model
        if best_state is not None:
            model.load_state_dict({k: v.to(device) for k, v in best_state.items()})

        # OOF predictions (with TTA)
        oof_preds[val_idx] = predict_tta(model, X_val_p, wns, device, n_tta=TTA_N)

        # Test predictions (with TTA)
        fold_test_preds = predict_tta(model, X_tst_p, wns, device, n_tta=TTA_N)
        test_preds += fold_test_preds / N_FOLDS

        # Per-fold metrics
        target_names = ["Glucose", "Sodium Acetate", "Magnesium Acetate"]
        oof_r2s = [r2_score(y_val[:, i], oof_preds[val_idx, i]) for i in range(N_TARGETS)]
        overall_r2 = np.mean(oof_r2s)
        fold_r2s.append(overall_r2)
        print(f"  Fold {fold+1} OOF R²: "
              + "  ".join(f"{n}={v:.4f}" for n, v in zip(target_names, oof_r2s))
              + f"  →  Avg={overall_r2:.4f}")

    return oof_preds, test_preds, fold_r2s


# ──────────────────────────────────────────────────────────────────────────────
# 10. Main
# ──────────────────────────────────────────────────────────────────────────────

def main():
    set_seed(SEED)
    os.makedirs(OUT_DIR, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # Shared wavenumber grid
    wns = make_grid(WN_LOW, WN_HIGH, WN_STEP)
    print(f"Wavenumber grid: {WN_LOW}–{WN_HIGH} cm⁻¹, {len(wns)} bins")

    # ── Load data ────────────────────────────────────────────────────────────
    print("\nLoading data …")
    X_val_raw, y_val = load_plate(
        os.path.join(DATA_DIR, "transfer_plate.csv"), is_train=True
    )
    X_test_raw, _ = load_plate(
        os.path.join(DATA_DIR, "96_samples.csv"), is_train=False
    )

    X_train = plate_to_grid(X_val_raw,  wns)
    X_test  = plate_to_grid(X_test_raw, wns)
    y_train = y_val

    print(f"  Train: {X_train.shape}  labels: {y_train.shape}")
    print(f"  Test : {X_test.shape}")

    # ── Cross-validated training ──────────────────────────────────────────────
    oof_preds, test_preds, fold_r2s = train_cv(
        X_train, y_train, X_test, wns, device
    )

    # ── Overall OOF metrics ───────────────────────────────────────────────────
    print("\n" + "="*70)
    print("  FINAL OOF RESULTS (Physics-Informed Neural Network)")
    print("="*70)
    target_names = ["Glucose (g/L)", "Sodium Acetate (g/L)", "Magnesium Acetate (g/L)"]
    oof_r2s = [r2_score(y_train[:, i], oof_preds[:, i]) for i in range(N_TARGETS)]
    for name, r2 in zip(target_names, oof_r2s):
        print(f"  {name:<26} R² = {r2:.4f}")
    print(f"  {'Overall average':<26} R² = {np.mean(oof_r2s):.4f}")
    print(f"\n  Fold R²s: " + "  ".join(f"{v:.4f}" for v in fold_r2s))
    print(f"  CV mean ± std: {np.mean(fold_r2s):.4f} ± {np.std(fold_r2s):.4f}")

    # ── Post-process predictions ──────────────────────────────────────────────
    print("\nPost-processing predictions …")
    test_preds_pp = post_process(test_preds, y_train)

    # ── Build submission ──────────────────────────────────────────────────────
    submission = pd.DataFrame({
        "ID":              np.arange(1, len(test_preds_pp) + 1),
        "Glucose":         test_preds_pp[:, 0],
        "Sodium Acetate":  test_preds_pp[:, 1],
        "Magnesium Sulfate": test_preds_pp[:, 2],   # note: submission uses MgSO4 col name
    })

    out_path = os.path.join(OUT_DIR, "submission_pinn.csv")
    submission.to_csv(out_path, index=False)
    print(f"\nSubmission saved → {out_path}")
    print(submission.head(10).to_string(index=False))

    # ── Validation report ─────────────────────────────────────────────────────
    print("\nSubmission validation:")
    print(f"  Shape            : {submission.shape}")
    print(f"  NaN values       : {submission.isna().sum().sum()}")
    cols = ["Glucose", "Sodium Acetate", "Magnesium Sulfate"]
    print(f"  Negative values  : {(submission[cols] < 0).sum().sum()}")

    return submission


if __name__ == "__main__":
    main()
